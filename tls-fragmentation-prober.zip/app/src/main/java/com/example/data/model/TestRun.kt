package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

data class TestResult(
    val length: Int,
    val interval: Double,
    val delay: Double
)

@Entity(tableName = "test_runs")
data class TestRun(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val targetHost: String,
    val targetPort: Int,
    val totalTests: Int,
    val successfulTests: Int,
    val bestLength: Int?,
    val bestInterval: Double?,
    val bestDelay: Double?,
    val resultsJson: String // Serialized List<TestResult>
) {
    fun getResultsList(): List<TestResult> {
        return try {
            val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
            val listType = Types.newParameterizedType(List::class.java, TestResult::class.java)
            val adapter = moshi.adapter<List<TestResult>>(listType)
            adapter.fromJson(resultsJson) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    companion object {
        fun serializeResults(results: List<TestResult>): String {
            return try {
                val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
                val listType = Types.newParameterizedType(List::class.java, TestResult::class.java)
                val adapter = moshi.adapter<List<TestResult>>(listType)
                adapter.toJson(results)
            } catch (e: Exception) {
                "[]"
            }
        }
    }
}
