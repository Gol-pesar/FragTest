package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.TestRun
import kotlinx.coroutines.flow.Flow

@Dao
interface TestRunDao {
    @Query("SELECT * FROM test_runs ORDER BY timestamp DESC")
    fun getAllTestRuns(): Flow<List<TestRun>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTestRun(testRun: TestRun)

    @Query("DELETE FROM test_runs WHERE id = :id")
    suspend fun deleteTestRunById(id: Int)

    @Query("DELETE FROM test_runs")
    suspend fun deleteAllTestRuns()
}
