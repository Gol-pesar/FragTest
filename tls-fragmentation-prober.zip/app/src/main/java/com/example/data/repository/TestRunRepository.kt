package com.example.data.repository

import com.example.data.db.TestRunDao
import com.example.data.model.TestRun
import kotlinx.coroutines.flow.Flow

class TestRunRepository(private val testRunDao: TestRunDao) {
    val allTestRuns: Flow<List<TestRun>> = testRunDao.getAllTestRuns()

    suspend fun insert(testRun: TestRun) {
        testRunDao.insertTestRun(testRun)
    }

    suspend fun deleteById(id: Int) {
        testRunDao.deleteTestRunById(id)
    }

    suspend fun deleteAll() {
        testRunDao.deleteAllTestRuns()
    }
}
