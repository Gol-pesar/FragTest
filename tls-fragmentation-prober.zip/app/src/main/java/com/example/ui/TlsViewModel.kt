package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.TestResult
import com.example.data.model.TestRun
import com.example.data.repository.TestRunRepository
import com.example.util.TlsTester
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface DiagnosticState {
    object Idle : DiagnosticState
    data class Running(
        val totalTests: Int,
        val currentTestIndex: Int,
        val currentLength: Int,
        val currentInterval: Double,
        val successfulCount: Int
    ) : DiagnosticState
    data class Completed(
        val run: TestRun
    ) : DiagnosticState
    data class Error(val message: String) : DiagnosticState
}

class TlsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: TestRunRepository
    val history: StateFlow<List<TestRun>>

    private val _diagnosticState = MutableStateFlow<DiagnosticState>(DiagnosticState.Idle)
    val diagnosticState: StateFlow<DiagnosticState> = _diagnosticState.asStateFlow()

    private val _liveLogs = MutableStateFlow<List<String>>(emptyList())
    val liveLogs: StateFlow<List<String>> = _liveLogs.asStateFlow()

    init {
        val database = AppDatabase.getDatabase(application)
        repository = TestRunRepository(database.testRunDao())
        history = repository.allTestRuns.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    private var isJobRunning = false

    fun startDiagnostic(
        host: String,
        port: Int,
        lengths: List<Int>,
        intervals: List<Double>,
        timeoutMs: Int = 3000
    ) {
        if (isJobRunning) return
        isJobRunning = true

        viewModelScope.launch {
            _diagnosticState.value = DiagnosticState.Idle
            _liveLogs.value = emptyList()
            
            val cleanHost = host.trim()
            if (cleanHost.isEmpty()) {
                _diagnosticState.value = DiagnosticState.Error("Host/IP is required")
                isJobRunning = false
                return@launch
            }

            logMessage("[*] Initializing manual ClientHello builder...")

            // Determine Server Name Indication (SNI) if host is not a raw IP address
            val isIp = cleanHost.replace(".", "").all { it.isDigit() }
            val serverName = if (!isIp) cleanHost else null
            if (serverName != null) {
                logMessage("[*] Target is domain. SNI set to: $serverName")
            } else {
                logMessage("[*] Target is raw IP. SNI disabled.")
            }

            val clientHelloRaw = try {
                val bytes = TlsTester.buildClientHello(serverName)
                logMessage("[*] Manual TLS ClientHello built successfully (${bytes.size} bytes)")
                bytes
            } catch (e: Exception) {
                logMessage("[-] Failed to build ClientHello: ${e.message}")
                _diagnosticState.value = DiagnosticState.Error("Failed to build ClientHello: ${e.message}")
                isJobRunning = false
                return@launch
            }

            val testConfigs = mutableListOf<Pair<Int, Double>>()
            for (length in lengths) {
                for (interval in intervals) {
                    testConfigs.add(Pair(length, interval))
                }
            }

            val totalTests = testConfigs.size
            if (totalTests == 0) {
                _diagnosticState.value = DiagnosticState.Error("No configurations to test. Please specify lengths and intervals.")
                isJobRunning = false
                return@launch
            }

            logMessage("[*] Scheduled $totalTests diagnostic checks. Starting test suite...")

            _diagnosticState.value = DiagnosticState.Running(
                totalTests = totalTests,
                currentTestIndex = 0,
                currentLength = lengths.firstOrNull() ?: 0,
                currentInterval = intervals.firstOrNull() ?: 0.0,
                successfulCount = 0
            )

            val results = mutableListOf<TestResult>()
            var successCount = 0

            withContext(Dispatchers.IO) {
                for (index in testConfigs.indices) {
                    if (!isJobRunning) {
                        logMessage("[-] Diagnostics process cancelled by user.")
                        break
                    }

                    val config = testConfigs[index]
                    val length = config.first
                    val interval = config.second

                    _diagnosticState.value = DiagnosticState.Running(
                        totalTests = totalTests,
                        currentTestIndex = index + 1,
                        currentLength = length,
                        currentInterval = interval,
                        successfulCount = successCount
                    )

                    logMessage("[*] [${index + 1}/$totalTests] testing length=$length bytes, interval=${interval}s ...")

                    val delay = TlsTester.testFragmentation(
                        host = cleanHost,
                        port = port,
                        clientHelloRaw = clientHelloRaw,
                        length = length,
                        interval = interval,
                        timeoutMs = timeoutMs
                    )

                    if (delay != null) {
                        results.add(TestResult(length, interval, delay))
                        successCount++
                        logMessage("    -> [✓] Success! delay = ${String.format("%.4f", delay)} s")
                    } else {
                        logMessage("    -> [✗] Failed / Connection Timeout")
                    }
                }
            }

            if (!isJobRunning) {
                _diagnosticState.value = DiagnosticState.Idle
                return@launch
            }

            isJobRunning = false

            if (results.isEmpty()) {
                logMessage("[-] Error: All connections failed or timed out.")
                _diagnosticState.value = DiagnosticState.Error("No successful tests. All diagnostic checks timed out or failed to connect.")
                return@launch
            }

            // Sort results by lowest delay
            results.sortBy { it.delay }
            val bestResult = results.first()

            logMessage("[*] Diagnostics completed successfully!")
            logMessage("[*] Optimal Config: length=${bestResult.length} bytes, interval=${bestResult.interval}s with delay=${String.format("%.4f", bestResult.delay)}s")

            val run = TestRun(
                targetHost = cleanHost,
                targetPort = port,
                totalTests = totalTests,
                successfulTests = successCount,
                bestLength = bestResult.length,
                bestInterval = bestResult.interval,
                bestDelay = bestResult.delay,
                resultsJson = TestRun.serializeResults(results)
            )

            repository.insert(run)
            _diagnosticState.value = DiagnosticState.Completed(run)
        }
    }

    fun stopDiagnostics() {
        isJobRunning = false
        _diagnosticState.value = DiagnosticState.Idle
        logMessage("[-] Cancelled by user.")
    }

    private fun logMessage(msg: String) {
        _liveLogs.value = _liveLogs.value + msg
    }

    fun deleteRun(id: Int) {
        viewModelScope.launch {
            repository.deleteById(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.deleteAll()
        }
    }

    fun resetState() {
        _diagnosticState.value = DiagnosticState.Idle
        _liveLogs.value = emptyList()
    }
}
