package com.example.util

import android.util.Log
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.security.SecureRandom

object TlsTester {

    private const val TAG = "TlsTester"

    fun buildClientHello(serverName: String?): ByteArray {
        val tlsVersion = byteArrayOf(0x03.toByte(), 0x03.toByte())
        
        // Random: 4 bytes epoch time + 28 bytes random
        val randomBytes = ByteArray(32)
        val epochTime = (System.currentTimeMillis() / 1000).toInt()
        randomBytes[0] = (epochTime shr 24).toByte()
        randomBytes[1] = (epochTime shr 16).toByte()
        randomBytes[2] = (epochTime shr 8).toByte()
        randomBytes[3] = epochTime.toByte()
        SecureRandom().nextBytes(randomBytes)
        // Keep the first 4 bytes as epochTime
        randomBytes[0] = (epochTime shr 24).toByte()
        randomBytes[1] = (epochTime shr 16).toByte()
        randomBytes[2] = (epochTime shr 8).toByte()
        randomBytes[3] = epochTime.toByte()
        
        // Session ID (empty)
        val sessionIdLen = byteArrayOf(0x00.toByte())
        val sessionId = byteArrayOf()
        
        // Cipher Suites
        val cipherSuites = intArrayOf(0xc02b, 0xc02c, 0xcc14)
        val cipherSuitesBytes = ByteArray(cipherSuites.size * 2)
        for (i in cipherSuites.indices) {
            cipherSuitesBytes[i * 2] = (cipherSuites[i] shr 8).toByte()
            cipherSuitesBytes[i * 2 + 1] = cipherSuites[i].toByte()
        }
        val cipherSuitesLen = byteArrayOf(
            (cipherSuitesBytes.size shr 8).toByte(),
            cipherSuitesBytes.size.toByte()
        )
        
        // Compression Methods
        val compressionMethods = byteArrayOf(0x00.toByte())
        val compressionLen = byteArrayOf(0x01.toByte())
        
        // Extensions
        var extensions = byteArrayOf()
        
        // SNI (Server Name Indication)
        if (!serverName.isNullOrEmpty()) {
            val serverNameBytes = serverName.toByteArray(Charsets.UTF_8)
            val sniLen = serverNameBytes.size
            
            val sniData = ByteArray(1 + 2 + sniLen)
            sniData[0] = 0x00.toByte() // host_name type
            sniData[1] = (sniLen shr 8).toByte()
            sniData[2] = sniLen.toByte()
            System.arraycopy(serverNameBytes, 0, sniData, 3, sniLen)
            
            val sniExt = ByteArray(2 + 2 + sniData.size)
            sniExt[0] = 0x00.toByte() // Extension Type: 0x0000
            sniExt[1] = 0x00.toByte()
            sniExt[2] = (sniData.size shr 8).toByte()
            sniExt[3] = sniData.size.toByte()
            System.arraycopy(sniData, 0, sniExt, 4, sniData.size)
            
            extensions += sniExt
        }
        
        // Supported Versions (\x00\x0b and body \x02\x03\x03)
        val supportedVersions = byteArrayOf(0x02.toByte(), 0x03.toByte(), 0x03.toByte())
        val extSupportedVersions = ByteArray(2 + 2 + supportedVersions.size)
        extSupportedVersions[0] = 0x00.toByte()
        extSupportedVersions[1] = 0x0b.toByte()
        extSupportedVersions[2] = (supportedVersions.size shr 8).toByte()
        extSupportedVersions[3] = supportedVersions.size.toByte()
        System.arraycopy(supportedVersions, 0, extSupportedVersions, 4, supportedVersions.size)
        
        extensions += extSupportedVersions
        
        // Signature Algorithms
        val sigAlgs = byteArrayOf(0x04.toByte(), 0x01.toByte(), 0x04.toByte(), 0x03.toByte())
        val sigAlgsLen = sigAlgs.size
        val extSigAlgs = ByteArray(2 + 2 + 2 + sigAlgsLen)
        extSigAlgs[0] = 0x00.toByte()
        extSigAlgs[1] = 0x0d.toByte()
        val totalSigExtLen = sigAlgsLen + 2
        extSigAlgs[2] = (totalSigExtLen shr 8).toByte()
        extSigAlgs[3] = totalSigExtLen.toByte()
        extSigAlgs[4] = (sigAlgsLen shr 8).toByte()
        extSigAlgs[5] = sigAlgsLen.toByte()
        System.arraycopy(sigAlgs, 0, extSigAlgs, 6, sigAlgsLen)
        
        extensions += extSigAlgs
        
        val extensionsLen = byteArrayOf(
            (extensions.size shr 8).toByte(),
            extensions.size.toByte()
        )
        
        // Build ClientHello Body
        val bodyStream = ByteArrayOutputStream()
        bodyStream.write(tlsVersion)
        bodyStream.write(randomBytes)
        bodyStream.write(sessionIdLen)
        bodyStream.write(sessionId)
        bodyStream.write(cipherSuitesLen)
        bodyStream.write(cipherSuitesBytes)
        bodyStream.write(compressionLen)
        bodyStream.write(compressionMethods)
        bodyStream.write(extensionsLen)
        bodyStream.write(extensions)
        val clientHelloBody = bodyStream.toByteArray()
        
        // Handshake Record
        val handshakeType = byteArrayOf(0x01.toByte())
        val bodyLen = clientHelloBody.size
        val handshakeLen = byteArrayOf(
            (bodyLen shr 16).toByte(),
            (bodyLen shr 8).toByte(),
            bodyLen.toByte()
        )
        
        val handshakeStream = ByteArrayOutputStream()
        handshakeStream.write(handshakeType)
        handshakeStream.write(handshakeLen)
        handshakeStream.write(clientHelloBody)
        val handshakeMessage = handshakeStream.toByteArray()
        
        // TLS Record
        val recordType = byteArrayOf(0x16.toByte())
        val recordVersion = byteArrayOf(0x03.toByte(), 0x03.toByte())
        val recordLenVal = handshakeMessage.size
        val recordLen = byteArrayOf(
            (recordLenVal shr 8).toByte(),
            recordLenVal.toByte()
        )
        
        val recordStream = ByteArrayOutputStream()
        recordStream.write(recordType)
        recordStream.write(recordVersion)
        recordStream.write(recordLen)
        recordStream.write(handshakeMessage)
        
        return recordStream.toByteArray()
    }

    fun testFragmentation(
        host: String,
        port: Int,
        clientHelloRaw: ByteArray,
        length: Int,
        interval: Double,
        timeoutMs: Int = 5000
    ): Double? {
        var socket: Socket? = null
        try {
            socket = Socket()
            socket.soTimeout = timeoutMs
            socket.tcpNoDelay = true

            // Connect to target
            socket.connect(InetSocketAddress(host, port), timeoutMs)

            val outputStream: OutputStream = socket.getOutputStream()
            val inputStream: InputStream = socket.getInputStream()

            val totalLen = clientHelloRaw.size
            val pieces = mutableListOf<ByteArray>()
            var offset = 0
            while (offset < totalLen) {
                val chunkSize = minOf(length, totalLen - offset)
                val chunk = ByteArray(chunkSize)
                System.arraycopy(clientHelloRaw, offset, chunk, 0, chunkSize)
                pieces.add(chunk)
                offset += chunkSize
            }

            val sendStart = System.nanoTime()

            for (i in pieces.indices) {
                outputStream.write(pieces[i])
                outputStream.flush()
                if (i < pieces.size - 1) {
                    if (interval > 0.0) {
                        Thread.sleep((interval * 1000).toLong())
                    }
                }
            }

            // Read at least 1 byte of response
            val firstByte = inputStream.read()
            if (firstByte != -1) {
                val delayNano = System.nanoTime() - sendStart
                return delayNano.toDouble() / 1_000_000_000.0
            }
            return null
        } catch (e: Exception) {
            Log.e(TAG, "Failed testing length=$length, interval=$interval: ${e.message}")
            return null
        } finally {
            try {
                socket?.close()
            } catch (e: Exception) {
                // Ignore
            }
        }
    }
}
